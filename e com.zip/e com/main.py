from auth import login
from database.config import con,cur

def get_user():
    name = input("Enter your name :")
    email = input("Enter your email :")
    password = input("Enter your password :")
    role = input("Enter your role :")

    user = {
        "name":name,
        "email":email,
        "password":password,
        "role":role
    }
    return user

while True:
    print("-"*50)
    print("welcome")
    print("-"*50)
    
    print("1.admin")
    print("2.user")
    print("0.exit")
    print("-"*50)
    
    ch = (input("Enter the choice : "))
    if ch == "1":
        print("welcome to admin")
        print("-"*20)
        login(get_user())
    elif ch == "2":
        print("welcome to user")
    elif ch == "0":
        print("bye.....!")
        break
    else:
        print("invalid....!")