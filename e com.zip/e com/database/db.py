# from config import cur
from mysql.connector import connect as con

con = con(
    host="localhost",
    username="root",
    password="root",
    database="python_dbms_ecom"
)

cur = con.cursor()
# print(cur)

def getUserFromDB():
    query = "select * from user;"
    cur.execute(query)
    users = cur.fetchall()
    print(users)
    usersDic = []
    for i in users:
        user = {
            "id":i[0],
            "name":i[1],
            "email":i[2],
            "password":i[3],
            "role":i[5]
        }
        usersDic.append(user)
    return usersDic
