from mysql.connector import connect as con

con = con(
    host="localhost",
    username="root",
    password="root",
    database="python_dbms_ecom"
)

cur = con.cursor()
# print(cur)