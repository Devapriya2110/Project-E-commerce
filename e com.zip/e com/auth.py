from database.db import getUserFromDB
from database.config import con,cur
    # user = {
    #     "name":name,
    #     "email":email,
    #     "password":password,
    #     "role":role
    # }

def login(user):
    print("welcome tp login...!")
    users = getUserFromDB()
    f = False
    for i in users:
        if i["email"] == user["email"]:
            if i["password"] == user["password"]:
                print("login....!")
                f = True
                break
            print("Password does not match...!")
    if f == False:
        print("user not found...!")            